/*************************************************************
 * sph_convert.h
 *------------------------------------------------------------
 *		 primary header file for sph_convert.c
 *			and other related .c files
 *
 * This takes care of all other necessary #include's, all program-wide
 * #define's, all function declarations, and global variables
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <malloc.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef _SPH_CONVERT_MAIN_
#define GLOBAL
#else
#define GLOBAL extern
#endif

#define STD_BUF_SIZE 16384
#define PCM 2
#define ULAW 1
#define UNKNOWN 0

/* Functions used by both MS-Windows and MacOS:
 *   int functions return 0 for success, non-zero (usually 1) for failure
 *   void functions will exit on failure
 */
int readSphHeader( const char * ); /* as the name implies... */
int ConverFile( char *, char * );  /* handles sphere input -> riff/raw output */
void writeRIFFHeader( void );      /* as the name implies... */
int shortenXtract( void );         /* handles data i/o for shortened files */
int copySamples( char * );         /* handles data i/o for uncomprsd files */
void demux( int );                 /* handles demultiplexing of 2-ch files */
unsigned char pcm2ulaw( long );    /* converts a pcm sample to a ulaw value */

/* Global variables:
 */

GLOBAL int samprate, samptype, sampsize, sampcount, chancount, doshorten;
GLOBAL int chanout, sizeout;
GLOBAL char inporder[4], *nativorder, *outorder, *outtype;
GLOBAL char mesgbuf[512];
GLOBAL FILE *fpin, *fpout;
GLOBAL char *inpath, *inpbuf, *outbuf;
GLOBAL int isRecursive, inpathLen;

GLOBAL union {
    char ch[2];
    short int i2;
} short_order;

GLOBAL union {
    char ch[4];
    int i4;
} long_order;

/* The following "pseudo-typedefs" are adopted for the sake of
 * working with Tony Robinson's "shorten" source code
 */
#undef	uchar
#define uchar	unsigned char
#undef	schar
#define schar	signed char
#undef	ushort
#define ushort	unsigned short
#undef	ulong
#define ulong	unsigned long
