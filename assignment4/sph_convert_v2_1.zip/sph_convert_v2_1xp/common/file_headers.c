/*************************************************************
 * Source File:	file_headers.c
 * Compilation:	gcc -o sph_convert sph_convert.c shorten_x.c file_headers.c wintel_funcs.c
 * Author:	Dave Graff, Willie Dong; LDC, University of Pennsylvania
 * Purpose:	functions to read SPHERE headers, write RIFF headers
 */

#include "sph_convert.h"

static char hdr[90];

/*************************************************************
 * readSphHeader
 *------------------------------------------------------------
 * get relevant fields from input sphere file header; return true (1) for success;
 * return false if:
 * - input file appears not to contain a sphere header
 * - header does not contain all of these fields:
 *      channel_count, sample_count, sample_rate, sample_n_bytes, sample_coding(*)
 *      (* if sample_coding is missing, assume uncompressed pcm)
 * - there is no data following the header
 * If these conditions pass, check first four bytes of data to confirm whether
 * file is "shorten" compressed, then assign values to corresponding globals
 */

int readSphHeader( const char *path )
{
    int n, hdrsize;
    char *field, fldname[24], fldtype[8], fldsval[32];

    if (( fpin = fopen( path, "rb" )) == NULL ) {
	printf( "Unable to open input file %s\n", path );
	return(-1);
    }
    n = fread( inpbuf, 1, 1028, fpin ); /* nearly all sphere headers are 1024 bytes */
    if ( n != 1028 || strncmp( inpbuf, "NIST_1A", 7 ) ||
	sscanf( &inpbuf[8], "%d", &hdrsize ) != 1 ) {
	rewind( fpin );
	return 0;
    }
    if ( hdrsize > 1024 ) {
	if ( hdrsize >= STD_BUF_SIZE ) { /* very unlikely, but best to be careful */
	    free( inpbuf );
	    if (( inpbuf = (char *) malloc( hdrsize+4 )) == NULL ) {
		printf( "Not enough memory for %d byte sphere header in %s\n",
			hdrsize, path );
		exit(1);
	    }
	}
	fseek( fpin, 0, 0 );
	n = fread( inpbuf, 1, hdrsize+4, fpin );
	if ( n != hdrsize+4 ) {
	    printf( "Failed to read %d byte sphere header in %s\n", hdrsize, path );
	    return -1;
	}
    }
    samptype = sampsize = sampcount = samprate = chancount = UNKNOWN;
    strcpy( inporder, " " );
    field = strtok( inpbuf, "\n" );
    while ( field != NULL && strcmp( field, "end_head" ))
    {
	if ( !strncmp( field, "channel_count -i ", 17 ))
	    sscanf( field, "%s %s %d", fldname, fldtype, &chancount );
	else if ( !strncmp( field, "sample_count -i ", 16 ))
	    sscanf( field, "%s %s %d", fldname, fldtype, &sampcount );
	else if ( !strncmp( field, "sample_rate -i ", 15 ))
	    sscanf( field, "%s %s %d", fldname, fldtype, &samprate );
	else if ( !strncmp( field, "sample_n_bytes -i ", 18 ))
	    sscanf( field, "%s %s %d", fldname, fldtype, &sampsize );
	else if ( !strncmp( field, "sample_byte_format -s2 ", 23 ))
	    sscanf( field, "%s %s %2s", fldname, fldtype, inporder );
	else if ( !strncmp( field, "sample_coding -s", 16 )) {
	    sscanf( field, "%s %s %s", fldname, fldtype, fldsval );
	    samptype =
		( !strncmp( fldsval, "ulaw", 4 )) ?  ULAW :
		( !strncmp( fldsval, "pcm", 3 ))  ?  PCM  : UNKNOWN;
	}
	field = strtok( NULL, "\n" );
    }
    if ( strcmp( field, "end_head" )) { /* this shouldn't happen */
	return -1;
    }
/* sometimes (in older TI corpora), "sample_coding" is not specified,
 * and in these cases, we can equate sample_n_bytes to sample_coding
 * (1=ulaw, 2=pcm)
 */
    if ( samptype == UNKNOWN )
	samptype = sampsize;
    
/* having done that, the following things must be known, or else
 * we don't really have a usable sphere file:
 */
    if ( !samptype || !sampcount || !samprate || !chancount ||
	( samptype == PCM && !strcmp( inporder, " " ))) {
	printf( "Incomplete/unusable sphere header in %s\n", path );
	return -1;
    }
/* Now that we're done with the text data in the sphere header, look
 * at the first four bytes of waveform data to see if it's shortened
 */
    if ( !strncmp( &inpbuf[hdrsize], "ajkg", 4 ))  /* the "magic number" for shorten */
	doshorten = 1;
    else {	/* when not shortened, we can try to check file size vs. header specs */
	struct stat statbuf;
	int fdin;
	doshorten = 0;
	fdin = fileno( fpin );
	if ( fstat( fdin, &statbuf ) < 0 )
	    printf( "Warning: unable to determine size of %s\n", path );
	else {
	    n = hdrsize + chancount * sampcount * samptype;
	    if ( statbuf.st_size != n ) { /* if they conflict, believe the file size */
		printf( "Warning: file size (%d) contradicts header in %s\n",
			statbuf.st_size, path );
		sampcount = ( statbuf.st_size - hdrsize ) / ( chancount * samptype );
	    }
	}
    }
    /* leave file pointer at end of header (start of data)
     */
    fseek( fpin, hdrsize, 0 );
    return 1;
}

/*************************************************************
 * copycharr
 *------------------------------------------------------------
 * could've used memcopy, but this feels more stable...
 */
static void copycharr( char *from, char *to, int n )
{
    int i;
    for ( i=0; i<n; i++ )
	*to++ = *from++;
}

/*************************************************************
 * copylong
 *------------------------------------------------------------
 * copy a 4-byte int, making sure to use the intended byte
 * order for the destination, regardless of what the
 * native byte order is on the current machine
 */
static void copylong( int val, char *dest, char *intended )
{
    int i, e, incr;

    if ( strcmp( nativorder, intended )) { 
	i = 3;
	e = -1;
	incr = -1;
    }
    else {
	i = 0;
	e = 4;
	incr = 1;
    }
    long_order.i4 = val;
    for ( ; i != e; i += incr )
	*dest++ = long_order.ch[i];
}

/*************************************************************
 * copyshort
 *------------------------------------------------------------
 * copy a 2-byte int, making sure to use the intended byte
 * order for the destination, regardless of what the
 * native byte order is on the current machine
 */
static void copyshort( short int val, char *dest, char *intended )
{
	if ( strcmp( nativorder, intended ))
	swab((char *) &val, short_order.ch, 2 );
    else
	short_order.i2 = val;

    *dest++ = short_order.ch[0];
    *dest = short_order.ch[1];
}

/*************************************************************
 * writeRIFFHeader
 *------------------------------------------------------------
 * The following documentation about the RIFF header format has been
 * copied verbatim from "wav.c" in sox-12.17; the copyright notice
 * contained in that source file is included, and applies to the
 * following commentary:

----- excerpt from sox-12.17/wav.c 
----- (available from http://home.sprynet.com/~cbagwell/sox.html)

 * Microsoft's WAVE sound format driver
 *
 * This source code is freely redistributable and may be used for
 * any purpose.  This copyright notice must be maintained. 
 * Lance Norskog And Sundry Contributors are not responsible for 
 * the consequences of using this software.
 *
 * ... [See note below.  -- DG/LDC]
 *
 * NOTE: Previous maintainers weren't very good at providing contact
 * information.
 *
 * Copyright 1992 Rick Richardson
 * Copyright 1991 Lance Norskog And Sundry Contributors
 *
 * ...
 *
 * Info for format tags can be found at:
 *   http://www.microsoft.com/asf/resources/draft-ietf-fleischman-codec-subtree-01.txt

... write .wav headers as follows:
 
bytes      variable      description
0  - 3     'RIFF'
4  - 7     wRiffLength   length of file minus the 8 byte riff header
8  - 11    'WAVE'
12 - 15    'fmt '
16 - 19    wFmtSize       length of format chunk minus 8 byte header 
20 - 21    wFormatTag     identifies PCM, ULAW etc
22 - 23    wChannels      
24 - 27    wSamplesPerSecond   samples per second per channel
28 - 31    wAvgBytesPerSec     non-trivial for compressed formats
32 - 33    wBlockAlign         basic block size
34 - 35    wBitsPerSample      non-trivial for compressed formats

PCM formats then go straight to the data chunk:
36 - 39    'data'
40 - 43     wDataLength   length of data chunk minus 8 byte header
44 - (wDataLength + 43)    the data

non-PCM formats must write an extended format chunk and a fact chunk:

ULAW, ALAW formats:
36 - 37    wExtSize = 0  the length of the format extension
38 - 41    'fact'
42 - 45    wFactSize = 4  length of the fact chunk minus 8 byte header
46 - 49    wSamplesWritten   actual number of samples written out
50 - 53    'data'
54 - 57     wDataLength   length of data chunk minus 8 byte header
58 - (wDataLength + 57)    the data

...
----- end of excerpt

 * Note: The source code change history (and source code) was omitted;
 * Stan Brooks (stabro@megsinet.com) and Chris Bagwell
 * (cbagwell@sprynet.com) authored several recent improvements
 * to wav.c, including the documentation quoted above.
 *
 * The following approach, written by David Graff for the LDC,
 * supports output to stdout (this was not supported in sox-12.17,
 * probably because sox included support for various RIFF-based
 * forms of compression, which are not supported here).
 */
void writeRIFFHeader( void )
{
	char *ordr = "01";		/* RIFF header wants ints with low-byte first */
	int fsize, hsize, hoffs;
	short int nbyts, nchan, fmtyp;
  
    nchan = ( chanout < chancount ) ?  1 : chancount;
    nbyts = nchan * sizeout;
    fsize = sampcount * nbyts;
    if ( sizeout == ULAW ) {
	hoffs = 18;
	hsize = 50;
	fmtyp = 0x0007;
    } else {
	hoffs = 16;
	hsize = 36;
	fmtyp = 0x0001;
    }
    copycharr( "RIFF", &hdr[0], 4 );
    copylong( fsize + hsize, &hdr[4], ordr );
    copycharr( "WAVE", &hdr[8], 4 );
    copycharr( "fmt ", &hdr[12], 4 );
    copylong( hoffs, &hdr[16], ordr );
    copyshort( fmtyp, &hdr[20], ordr );
    copyshort( nchan, &hdr[22], ordr );
    copylong( samprate, &hdr[24], ordr );
    copylong( nbyts * samprate, &hdr[28], ordr );
    copyshort( nbyts, &hdr[32], ordr );
    copyshort( sizeout * 8, &hdr[34], ordr );
    hoffs = 36;
    if ( sizeout == ULAW ) {
	copyshort( 0, &hdr[36], ordr );
	copycharr( "fact", &hdr[38], 4 );
	copylong( 4, &hdr[42], ordr );
	copylong( sampcount, &hdr[46], ordr );
	hoffs = 50;
    }
    copycharr( "data", &hdr[hoffs], 4 );
    copylong( fsize, &hdr[hoffs+4], ordr );

    hsize += 8; /* add in the first 8 bytes, which weren't included earlier */
    if ( fwrite( hdr, 1, hsize, fpout ) != hsize ) {
	printf( "Failed to write output WAV header\n" );
	exit(1);
    }
}

