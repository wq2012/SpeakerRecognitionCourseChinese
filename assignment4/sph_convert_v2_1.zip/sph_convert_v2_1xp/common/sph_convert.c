/*************************************************************
 * Source File:	sph_convert.c
 * Compilation:
 *    gcc -o sph_convert sph_convert.c shorten_x.c file_headers.c wintel_funcs.c macos_funcs.c
 * Authors:	Dave Graff, LDC, University of Pennsylvania
 * Purpose:	multi-platform utility for converting SPHERE waveform files
 *		to other common digital audio file formats
 * Usage:
 *  sph_convert [-p|-u] [-c 1|2] [-f raw] infile_spec
 *		where "infile_spec" may contain a path and/or wildcards, or
 *  sph_convert [-p|-u] [-c 1|2] [-f raw] -r input_path
 *
 * The NIST "SPHERE" file format for waveform data consists of a plain-text
 * header that describes the file contents, followed by the raw (binary)
 * sample data; the size of the sphere header is always a multiple of 1024
 * bytes, and is always stated as an ASCII digit string in the second line
 * of text (bytes 8-15 of the file); the description of content always
 * includes the following elements:
 *  - sample rate
 *  - bytes per sample
 *  - byte order (when bytes per sample is > 1)
 *  - channel count
 *  - sample count
 *  - sample coding -- one of: mulaw or pcm (linear signed integer)
 *  - whether the sample data are compressed
 * Other information may be contained in the header as well, but this has
 * no effect on the conversion to other file formats.
 *
 * Apple/Macintosh and Intel/Microsoft systems typically support RIFF
 * format for digital audio data, and users of these systems typically
 * do not have tools that can use sphere-formatted files as input.
 * `sph_convert' will produce usable RIFF versions of sphere files so
 * that the waveform data is accessible using common tools on these
 * systems.
 *
 * Input conditions: sph_convert handles any sphere file as input
 *  - read from disk or cdrom
 *  - may be shorten compressed, or not
 *  - may be single- or two-channel
 *  - may be pcm or ulaw (mu-law)
 *  - if 2-byte pcm, may be either byte-order (HL or LH)
 *  - may be any sample rate (typically 10, 11.025, 12.5, 16, 20, 22.1 KHz)
 *  - may be any size (from several KB to hundreds of MB)
 *  - non-sphere input files are simply skipped, or are copied verbatim
 *      if "-r input_path" is used.
 *
 * Output conditions:
 *  - format may be RIFF/WAV or headerless [-f wav/raw]
 *  - if two-channel, allow demux (output user-selected channel) [-c 1/2]
 *  - allow conversion of output to linear pcm [-p] or to ulaw [-u]
 *  - if outputting 2-byte pcm, use native byte order for target system
 *  - always uncompress when input is "shorten" compressed
 *  - always output full duration of input speech file
 *  - always output to a file with the same name, but suitable .ext
 *      use ".raw" for headerless output; if input file was ".wav" and
 *      output is RIFF/WAV written to same directory, rename input file
 *      to ".sph", and use ".wav" for output file name
 *
 * Overall method of operation:
 *  - allocate data buffers
 *  - determine current machine's native byte order
 *  - get user selections (from ms-dos command-line args or Mac-GUI):
 *     -- input file name pattern (can include wild-cards, or not)
 *     -- input directory path
 *     -- output directory path (default=CWD on ms-windows, no default(?) on Mac)
 *     -- output file format (default=RIFF/WAV)
 *     -- output channel (ignored for 1-ch input; default="both" for 2-ch)
 *     -- force pcm or ulaw output (default=same as input)
 *     -- convert/copy all files & subdirs (default=skip subdirs)
 *  - for each input file found:
 *    - read input sphere header for sample rate, etc.
 *    - create and output desired target file header, if any
 *    - loop over input data; for each buffer read from input:
 *     -- uncompress via "shorten extract" if necessary
 *     -- demux (discard one channel) if necessary
 *     -- convert to ulaw to pcm if necessary
 *     -- invert byte order if necessary
 *     -- write to output
 *    - close files
 *  - on Mac, user can reset/rerun or quit; 
 *       on ms-windows, just exit (one input spec per run)
 *
 * The program includes source code for "shorten-compressed" data extraction;
 * the shorten source code is copyright 1991-1999, Anthony J. Robinson.
 */

/* VERSION information:
 * This is version 2.0, intended only for ms-windows and Mac systems
 * Thanks to Leonid Spektor, Dept. of Psychology, CMU, for the Mac interface.
 */

#define _SPH_CONVERT_MAIN_

#include "sph_convert.h"
#include "ulaw.h"

int main( int argc, char **argv )
{
/* find out what the native byte order is:
 */
    short_order.i2 = 1;
    nativorder = ( short_order.ch[0] ) ? "01" : "10"; /* ie "LH" : "HL" */

/* make the data buffers
 */
    if (( outbuf = (char *) malloc( STD_BUF_SIZE*2 )) == NULL ||
	( inpbuf = (char *) malloc( STD_BUF_SIZE*2 )) == NULL ) {
	printf( "Not enough memory for %d byte buffer\n",
		STD_BUF_SIZE*4 );
	exit(1);
    }
    runCLI( argc, argv );
}

int CopyFile(char *outname)
{
    int t,r,w,ret;
    ret = 0;
    if (( fpout = fopen( outname, "wb" )) == NULL ) {
	printf( "Unable to open %s as output\n",
		outname );
	return(1);
    }
    t = 0;
    while (( r = fread( inpbuf, 1, STD_BUF_SIZE*2, fpin )) > 0 ) {
	if (( w = fwrite( inpbuf, 1, r, fpout )) != r ) {
	    printf( "File-write error on %s: %d read, %d written\n",
		    outname, t+r, t+w );
	    ret = 1;
	    break;
	}
	t += r;
    }
    fclose( fpout );
    return( ret );
}

int ConvertFile(char *inpname, char *outname)
{
    int i, n, ns, ret;
    short int *sptr, *sptr2;
    uchar *cptr, *cptr2;

    if (( fpout = fopen( outname, "wb" )) == NULL ) {
	printf( "Unable to open %s as output\n", outname );
	exit(1);
    }

    if ( sizeout == 0 )  /* command line didn't say, so */
	sizeout = samptype;  /* keep samptype same as input */
    if ( chancount == 1 )  /* if input is 1-channel, */
	chanout = chancount; /* "-c" option doesn't matter */

    if ( !strcmp( outtype, "RIFF" ))
	writeRIFFHeader();

/* If input is shortened, shortenXtract takes care of everything else
 */
    if ( doshorten )
	ret = shortenXtract();
    else
	ret = copySamples( outname );

    fclose( fpout );
    return( ret );
}

int copySamples( char *outname )
{
    int i, nb, ns, sampsdone;
    short int *sptr;
    uchar *cptr;
    char *wptr;

    sampsdone = 0;
    while (( nb = fread( inpbuf, 1, STD_BUF_SIZE, fpin )) > 0 &&
	   sampsdone < sampcount )
    {
	ns = nb / ( chancount * samptype );
	sampsdone += ns;
	if ( chancount > chanout ) { /* input chancount==2, chanout=0 or 1 */
	    demux( nb );
	    nb /= 2;
	}
	wptr = inpbuf;
	if ( samptype < sizeout ) { /* convert ulaw to pcm */
	    cptr = inpbuf;
	    sptr = (short int *) outbuf;
	    for ( i=0; i<nb; i++ )
		*sptr++ = ulaw2pcm[*cptr++];
	    nb *= 2;
	    if ( strcmp( nativorder, outorder )) /* if output filetype needs */
		swab( outbuf, inpbuf, nb );      /* it, do byte swapping too */
	    else
		wptr = outbuf;
	}
	else if ( samptype > sizeout ) { /* convert pcm to ulaw */
	    if ( strcmp( inporder, nativorder )) { /* if inp. filetype needs */
		swab( inpbuf, outbuf, nb );        /* it, do byte swap first */
		sptr = (short int *) outbuf;
		cptr = inpbuf;
	    } else {
		wptr = cptr = outbuf;
		sptr = (short int *) inpbuf;
	    }
	    for ( i=0; i<nb; i+=2 )
		*cptr++ = pcm2ulaw( *sptr++ );
	    nb /= 2;
	}
	else if ( samptype == 2 && strcmp( inporder, outorder )) {
	    swab( inpbuf, outbuf, nb );
	    wptr = outbuf;
	}
	if ( fwrite( wptr, 1, nb, fpout ) != nb ) {
	    printf( "Failed while writing sample data to %s\n",
		    outname );
	    exit( 1 );
	}
    }
    return( sampsdone != sampcount );
}

void demux( int ns )
{
    int i;
    short int *sptr, *sptr2;
    uchar *cptr, *cptr2;

/* To demultiplex, simply move the samples of the selected channel
 * so that they are adjacent starting at offset 0 of inpbuf; this
 * overwrites the unselected channel data.
 */
    if ( samptype == PCM ) {
	ns /= 2;
	i = chanout;
	sptr = (short int *) inpbuf;
	sptr2 = sptr + chanout;
	if ( chanout == 0 ) {
	    i = 2;
	    sptr++;
	    sptr2 += 2;
	}
	for ( ; i<ns; i+=2 ) {
	    *sptr++ = *sptr2;
	    sptr2 += 2;
	}
    } else {			/* samptype == MULAW */
	i = chanout;
	cptr = inpbuf;
	cptr2 = cptr + chanout;
	if ( chanout == 0 ) {
	    i = 2;
	    cptr++;
	    cptr2 += 2;
	}
	for ( ; i<ns; i+=2 ) {
	    *cptr++ = *cptr2;
	    cptr2 += 2;
	}
    }
}
