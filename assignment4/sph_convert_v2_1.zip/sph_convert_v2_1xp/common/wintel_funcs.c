/*************************************************************
 * Source File: wintel_funcs.c
 * Compilation:
 *    gcc -o sph_convert.c shorten_x.c file_headers.c wintel_funcs.c macos_funcs.c
 * Author:   Dave Graff, LDC, University of Pennsylvania
 * Purpose:  functions specific to the MS-WINDOWS/DOS CLI version of sph_convert
 *
 * runCLI(): called by main() to parse CLI options and run operations
 *	     accordingly; for recursive operation, it calls the
 *	     djgpp-specific "__file_tree_walk", which locates all
 *	     subdirectories & files in a given path, and for each,
 *	     calls:
 * cliRecurser(): checks the properties of the path provided by
 *                "__file_tree_walk"; for directories, create an
 *                equivalent output directory if necessary, take no
 *                other action unless the item is a data file, for
 *                which, call:
 * argv_walk(): given a complete file path, calls readSphHeader() to
 *              see if this is a sphere file; if so, adjust the file
 *              extension if needed and call ConvertFile; if not
 *              sphere, copy the content to the output path (unless
 *              working in-place)
 */

#ifdef MSDOS
#include "sph_convert.h"
#include <unistd.h>
#include <dir.h>

#define DIR_MASK 0x10
#define SKP_MASK 0x1c

char *cwd;
int inPlace, verbose;

/* For recursive operation in runCLI(), cliRecurser() is called by
 * __file_tree_walk() for each entry under inpath
 */
int cliRecurser( const char *path, const struct ffblk *ff )
{
    int offst;
    char outpath[512];

    offst = ( inPlace ) ?  0 : ( path[inpathLen+1] == '/' ) ? inpathLen+2 : inpathLen+1;
    strcpy( outpath, &path[offst] );

    if (( ff->ff_attrib & DIR_MASK ) && !inPlace )
	mkdir( outpath, S_IWUSR ); /* returns err.status if path exists -- no problem */

    if ( ff->ff_attrib & SKP_MASK ) /* true for dirs, vol.names, hidden & system files */
	return(0);

    argv_walk( path );
}


int argv_walk( const char *path )
{
    int ftyp, offst, ret;
    char outpath[512], *oext, ic, oc;
    const char *iext;

    offst = ( inPlace ) ?  0 : ( path[inpathLen+1] == '/' ) ? inpathLen+2 : inpathLen+1;
    strcpy( outpath, &path[offst] );

    ret = 0;
    ftyp = readSphHeader( path );
    if ( chancount == 1 || chancount == chanout ) {
	ic = 'h';
	oc = ( strcmp( outtype, "RIFF" )) ? 'w' : 'v';
    }
    else
	ic = oc = ( chanout == 0 ) ?  '1' : '2';

    switch ( ftyp ) {
      case -1:		/* unreadable file, or faulty sphere header */
	break;
      case 0:		/* non-sphere file */
	if ( !inPlace ) {  /* skip it if we're working in-place */
	    if ( verbose )
		printf( "copying %s to %s ...", path, outpath );
	    ret = CopyFile( outpath );
	}
	break;
      case 1:		/* sphere file: now we need to work on the filename extension */
	iext = &path[strlen(path)-3];
	oext = &outpath[strlen(outpath)-3];
	if ( inPlace && !strcmp( outtype, "RIFF" ) && !strncasecmp( iext, "wa", 2 )) {
	    oext[0] = 's';
	    oext[1] = 'p';
	    if (( oext[2] & 0x5f ) == 'V' ) oext[2] = ic;
	    if ( _rename( path, outpath )) {  /* non-zero return means failure to rename */
		oext[0] = 'm';
		oext[1] = 'w';  /* so go with a non-standard file extension for output */
		oext[2] = oc;
		if ( verbose )
		    printf( "unable to rename input %s -- output is %s ...", path, outpath );
		ret = ConvertFile( path, outpath );
	    } else {
		if ( verbose )
		    printf( "converting %s to %s ...", outpath, path );
		ret = ConvertFile( outpath, path );
	    }
	} else {
	    if ( !strcmp( outtype, "RIFF" )) {
		oext[0] = 'w';
		oext[1] = 'a';
		if (( oext[2] & 0x5f ) == 'H' ) oext[2] = oc;
	    } else {
		oext[0] = 'r';
		oext[1] = 'a';
		if (( oext[2] & 0x5f ) == 'H' || ( oext[2] & 0x5f ) == 'V' ) oext[2] = oc;
	    }
	    if ( verbose )
		printf( "converting %s to %s ...", path, outpath );
	    ret = ConvertFile( path, outpath );
	}
    }
    fclose( fpin );
    if ( verbose && ( ftyp || !inPlace )) {
	if ( ret )
	    printf( " ... failed\n");
	else
	    printf( " done\n");
    }
    return( 0 );
}


int runCLI( int ac, char **av )
{
    extern int optind;
    extern char *optarg;
    int i, j;
    char *sl, *usage = "Usage:\n\
sph_convert [-v] [-c 1|2] [-p|-u] [-f raw] infile_spec\n\
    where infile_spec may contain path and/or wild-cards; or:\n\
sph_convert [-v] [-c 1|2] [-p|-u] [-f raw] -r input_path\n\
    default operations:\n\
        * report problem files on stdout\n\
	* output all channels from input file\n\
	* output same sample coding as input file\n\
	* output format is WAV\n\
	* treat all files that match infile_spec\n\
    optional settings:\n\
        -v   : (verbose) report all file actions on stdout\n\
	-c 1 : only output first channel\n\
	-c 2 : only output second channel\n\
	-p   : force conversion to 16-bit linear pcm\n\
	-u   : force conversion to 8-bit mu-law\n\
	-f raw : select raw (headerless) output format\n\
	-r input_path : do all files under input_path, including subdirs\n\
                        - convert all sphere files, copy all other files\n\
         (note: use either '-r input_path' or 'infile_spec', not both)\n\
    output file name(s) (and subdirs) derived from input file name(s)'\n";

/* set initial default values for user-controllable options
 */
    verbose = 0;
    sizeout = 0;		/* means "same as input sample type" */
    chanout = 2;		/* means "same as input channel count" */
    outtype = "RIFF";

    while (( i = getopt( ac, av, "vpuc:f:r:" )) != EOF )
	switch ( i )
	{
	  case 'v':
	    verbose = 1;
	    break;
	  case 'r':		/* go through all subdirs */
	    isRecursive = 1;
	    inpath = strdup( optarg );
	    break;
	  case 'p':		/* force pcm output */
	    sizeout = PCM;
	    break;
	  case 'u':		/* force ulaw output */
	    sizeout = ULAW;
	    break;
	  case 'c':		/* output one channel */
	    chanout = ( *optarg == '1' ) ?  0 : ( *optarg == '2' ) ?  1 : -1;
	    break;
	  case 'f':		/* force a particular output format */
	    if ( strncasecmp( optarg, "RIF", 3 ) == 0 ||
		strncasecmp( optarg, "WAV", 3 ) == 0 )
		outtype = "RIFF";
	    else if ( strncasecmp( optarg, "RAW", 3 ) == 0 )
		outtype = "RAW";
	    else
		outtype = NULL;
	    if ( outtype != NULL )
		break;		/* otherwise, fall through to exit with "usage" report */
	  default:
	    fputs( usage, stderr );
	    return(1);
	}

    if ( isRecursive && optind < ac /* got infile_spec(s), and -r input_path too */
	|| !isRecursive && optind == ac ) { /* got neither */
	fputs( usage, stderr );
	return(1);
    }
    outorder = ( !strcmp( outtype, "RIFF" )) ?  "01" : nativorder;

/* To make sure we do the right things with input and output file names,
 * we need to know what directory we're in now (cwd) -- this will be where
 * output files are written:
 */
    cwd = getcwd( NULL, 256 );
    if ( cwd == NULL ) {
	printf( "Unable to determine current working directory\n" );
	return(1);
    }
/* Try to determine if "-r input_path" or "infile_spec" point to cwd; if so,
 * we'll be doing conversion "in-place", and affecting only sphere files.
 * Note that when infile_spec is given, the argv array always contains one
 * or more fully-specified file names (i.e. all that match a given pattern)
 * so getting the path portion of the first command-line arg should suffice.
 */
    if ( !isRecursive )	inpath = dirname( av[optind] );
    inpathLen = strlen( inpath );

    while (( sl = strchr( inpath, '\\' )) != NULL )  /* back-slashes? */
	*sl = '/';         /* we don't need no stinkin' back-slashes! */

    if ( inpath[inpathLen-1] == '/' ) {
	inpathLen--;
	inpath[inpathLen] = '\0';
    }
    inPlace =
	( !strcmp(inpath, cwd) || !strcmp(inpath, ".") || !strcmp(inpath, &cwd[2] )
	 || ( inpath[0] != '/' && inpath[1] != ':' ));

/* Now, either recurse over all files contained under inpath, or loop
 * over all files named in argv
 */
    if ( isRecursive )
	i = __file_tree_walk( inpath, cliRecurser );
    else {
	i = 0;
	for ( j=optind; (j<ac && i==0); j++ )
	    i = argv_walk( av[j] );
    }
    return(i);
}
#endif
